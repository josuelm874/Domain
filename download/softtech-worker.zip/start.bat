@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERRO] Node.js nao encontrado. Instale em https://nodejs.org && pause && exit /b 1)
if not exist node_modules (echo Instalando dependencias ^(primeira vez^)... && call npm install --omit=dev)
echo Subindo worker SoftTech em http://127.0.0.1:47620 ...
echo Deixe esta janela aberta enquanto usa o sistema.
node server.js
pause
