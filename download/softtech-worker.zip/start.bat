@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERRO] Node.js nao encontrado. Instale em https://nodejs.org && pause && exit /b 1)
if exist node_modules goto :run
echo Instalando dependencias OPCIONAIS ^(somente a DIRBI precisa^)...
call npm install --omit=dev
if errorlevel 1 echo [AVISO] npm install falhou. O download de NFCe funciona assim mesmo; apenas a DIRBI ficara indisponivel.
:run
echo Subindo worker SoftTech em http://127.0.0.1:47620 ...
echo Deixe esta janela aberta enquanto usa o sistema.
node server.js
pause
