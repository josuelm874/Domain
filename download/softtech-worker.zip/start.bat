@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"
title SoftTech Worker

set "NODE_VER=v22.23.2"
set "NODE_BASE=https://nodejs.org/dist/v22.23.2"
set "SHA_x64=1177b4137ba5adaa56354ae40f1080c7450e8ae09cecb47da459d1c52ac99f97"
set "SHA_x86=725c9e2bdd1c2016b41c995a81f4fa36ce4e2ee565b7455d8f889182727df647"

rem ---- 1) arquitetura REAL do Windows ----
rem PROCESSOR_ARCHITECTURE mente quando um processo 32 bits roda em SO 64 bits:
rem nesse caso o valor real vem em PROCESSOR_ARCHITEW6432. Por isso os dois testes.
rem ARM64 cai em x86 de proposito: todo Windows on ARM emula x86, mas so o Windows 11
rem emula x64 -- x86 e a escolha que funciona nos dois.
set "ARCH=x86"
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "ARCH=x64"
if /i "%PROCESSOR_ARCHITEW6432%"=="AMD64" set "ARCH=x64"

rem ---- 2) runtime ja presente nesta pasta? ----
set "NODE_EXE=%CD%\node\%ARCH%\node.exe"
if exist "%NODE_EXE%" goto :run

rem ---- 3) Node do sistema, se for recente o bastante ----
where node >nul 2>nul
if errorlevel 1 goto :bootstrap
set "SYSMAJOR="
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node" 2^>nul') do set "SYSMAJOR=%%v"
if not defined SYSMAJOR goto :bootstrap
rem Node antigo sobe e morre depois, em sintaxe moderna, com erro que nao ajuda.
rem Melhor ignora-lo aqui e baixar um que funciona.
if !SYSMAJOR! LSS 18 goto :bootstrap
set "NODE_EXE=node"
goto :run

:bootstrap
echo.
echo  Node.js utilizavel nao foi encontrado nesta maquina.
echo  Vou baixar o oficial %NODE_VER% ^(%ARCH%^) para DENTRO desta pasta.
echo  Nao instala nada no Windows, nao mexe no PATH, nao precisa de administrador.
echo.
set "ZIPNAME=node-%NODE_VER%-win-%ARCH%.zip"
set "WANT=!SHA_%ARCH%!"
echo  Baixando %ZIPNAME% ^(cerca de 30 MB^)...
where curl >nul 2>nul
if errorlevel 1 goto :dl_ps
curl -L --fail -o "%ZIPNAME%" "%NODE_BASE%/%ZIPNAME%"
if errorlevel 1 goto :dl_fail
goto :dl_ok
:dl_ps
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%NODE_BASE%/%ZIPNAME%' -OutFile '%ZIPNAME%'"
if errorlevel 1 goto :dl_fail
:dl_ok

rem ---- confere o SHA-256 antes de executar qualquer coisa ----
echo  Conferindo a assinatura do arquivo...
set "GOT="
for /f "skip=1 tokens=1" %%h in ('certutil -hashfile "%ZIPNAME%" SHA256') do if not defined GOT set "GOT=%%h"
if /i not "!GOT!"=="!WANT!" goto :hash_fail

rem ---- extrai: tar vem no Windows 10 1803+; Expand-Archive cobre o resto ----
echo  Extraindo...
if exist "node\_tmp" rmdir /s /q "node\_tmp"
mkdir "node\_tmp" 2>nul
where tar >nul 2>nul
if errorlevel 1 goto :unzip_ps
tar -xf "%ZIPNAME%" -C "node\_tmp"
if errorlevel 1 goto :unzip_ps
goto :unzip_ok
:unzip_ps
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIPNAME%' -DestinationPath 'node\_tmp' -Force"
if errorlevel 1 goto :unzip_fail
:unzip_ok
move "node\_tmp\node-%NODE_VER%-win-%ARCH%" "node\%ARCH%" >nul
if errorlevel 1 goto :unzip_fail
rmdir /s /q "node\_tmp" 2>nul
del /q "%ZIPNAME%" 2>nul
set "NODE_EXE=%CD%\node\%ARCH%\node.exe"
if not exist "%NODE_EXE%" goto :unzip_fail
echo  Pronto. O runtime ficou em node\%ARCH% e so sera baixado esta vez.
echo.

:run
rem Dependencia OPCIONAL: so a DIRBI usa exceljs, e lib/dirbi.js a carrega sob demanda.
rem Baixar NFCe sobe sem nenhum node_modules -- por isso a falha aqui nunca e fatal.
if exist node_modules goto :serve
set "NPM_CMD=%CD%\node\%ARCH%\npm.cmd"
if not exist "%NPM_CMD%" set "NPM_CMD=npm"
echo Instalando dependencias OPCIONAIS ^(somente a DIRBI precisa^)...
call "%NPM_CMD%" install --omit=dev
if not errorlevel 1 goto :serve
echo [AVISO] npm install falhou. O download de NFCe funciona assim mesmo;
echo          apenas a DIRBI ficara indisponivel.
rem Causa medida em teste: npm cria caminhos internos longos e estoura o limite
rem de 260 caracteres do Windows, falhando SEM MENSAGEM. Com a pasta em 228
rem caracteres o npm morreu calado; com 66 instalou os 108 pacotes.
echo          Causa comum: a pasta esta muito funda no disco. Mova o worker para
echo          uma pasta curta, logo na raiz do disco C:, e rode de novo.

:serve
rem Quem imprime a URL e o server.js -- ele conhece a porta de verdade. Fixar
rem 47620 nesta mensagem mentiria quando SOFTTECH_WORKER_PORT estiver setado.
echo Subindo o worker SoftTech. Deixe esta janela aberta enquanto usa o sistema.
"%NODE_EXE%" server.js
pause
exit /b 0

:dl_fail
echo.
echo  [ERRO] Nao consegui baixar o Node de %NODE_BASE%.
echo  Causa mais comum: proxy ou firewall da empresa bloqueando nodejs.org.
echo  Saida: peca o pacote OFFLINE ^(softtech-worker-offline.zip^), que ja vem com o
echo  runtime embutido e nao baixa nada.
del /q "%ZIPNAME%" 2>nul
pause
exit /b 1

:hash_fail
echo.
echo  [ERRO] O arquivo baixado NAO confere com a assinatura oficial do Node.
echo  esperado: !WANT!
echo  recebido: !GOT!
echo  Download corrompido, ou algo no caminho alterou o arquivo. Nao vou executa-lo.
del /q "%ZIPNAME%" 2>nul
pause
exit /b 1

:unzip_fail
echo.
echo  [ERRO] Baixou, conferiu, mas nao consegui extrair o runtime.
echo  Extraia "%ZIPNAME%" na mao e renomeie a pasta interna para node\%ARCH%.
pause
exit /b 1
