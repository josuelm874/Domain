#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "[ERRO] Node.js nao encontrado: https://nodejs.org"; exit 1; }
[ -d node_modules ] || npm install --omit=dev
echo "Subindo worker SoftTech em http://127.0.0.1:47620 ..."
node server.js
