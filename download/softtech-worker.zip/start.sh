#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "[ERRO] Node.js nao encontrado: https://nodejs.org"; exit 1; }
if [ ! -d node_modules ]; then
  echo "Instalando dependencias OPCIONAIS (somente a DIRBI precisa)..."
  npm install --omit=dev || echo "[AVISO] npm install falhou. O download de NFCe funciona assim mesmo; apenas a DIRBI ficara indisponivel."
fi
echo "Subindo worker SoftTech em http://127.0.0.1:47620 ..."
node server.js
