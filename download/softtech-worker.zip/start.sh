#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

case "$(uname -m)" in
  x86_64|amd64) ARCH=x64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  *) ARCH=x86 ;;
esac

# Runtime embarcado ao lado tem precedencia sobre o do sistema.
if [ -x "node/$ARCH/bin/node" ]; then
  NODE_EXE="./node/$ARCH/bin/node"
elif command -v node >/dev/null 2>&1; then
  NODE_EXE=node
else
  echo "[ERRO] Node.js nao encontrado. Instale pelo gerenciador de pacotes ou veja https://nodejs.org"
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "Instalando dependencias OPCIONAIS (somente a DIRBI precisa)..."
  npm install --omit=dev || echo "[AVISO] npm install falhou. O download de NFCe funciona assim mesmo; apenas a DIRBI ficara indisponivel."
fi
echo "Subindo o worker SoftTech. Deixe este terminal aberto."
"$NODE_EXE" server.js
